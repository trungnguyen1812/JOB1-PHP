import iPhone from 'assets/images/products/iPhone.png';
import Nike from 'assets/images/products/Nike.png';
import NightDress from 'assets/images/products/sleep-dress.png';
import CameraLens from 'assets/images/products/lens.png';
import ArganOil from 'assets/images/products/argan-oil.png';
import Parfum from 'assets/images/products/parfum.png';
import Laptop from 'assets/images/products/laptop.png';
import Tablet from 'assets/images/products/tablet.png';
import DSLR from 'assets/images/products/dslr.png';
import Drone from 'assets/images/products/drone.png';
import Speaker from 'assets/images/products/speaker.png';
import SmartWatch from 'assets/images/products/smart-watch.png';

export {
  iPhone,
  Nike,
  NightDress,
  CameraLens,
  ArganOil,
  Parfum,
  Laptop,
  Tablet,
  DSLR,
  Drone,
  Speaker,
  SmartWatch,
};
